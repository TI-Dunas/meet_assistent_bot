"""
Gera um relatório em Markdown a partir da transcrição, usando um modelo local
do Ollama (gratuito). Transcrições longas são resumidas em partes e depois unidas.
"""

from datetime import datetime
from pathlib import Path

import shutil

import requests

# Pasta padrão de dados do DietPi: aparece no File Browser do DietPi Dashboard.
# Em outros sistemas, o relatório fica na mesma pasta da transcrição.
PASTA_DIETPI = Path("/mnt/dietpi_userdata/reunioes")

OLLAMA_URL = "http://localhost:11434/api/chat"
TAMANHO_PARTE = 12000  # caracteres por trecho enviado ao modelo

PROMPT_PARTE = """Você recebe um trecho da transcrição automática de uma reunião (pode conter erros de reconhecimento de fala).
Extraia, em português, notas objetivas sobre o trecho:
- assuntos discutidos
- decisões tomadas
- tarefas combinadas (quem fará o quê e prazo, se mencionado)
- dúvidas ou pendências
Não invente nada que não esteja no texto."""

PROMPT_FINAL = """Você é um assistente que escreve atas de reunião em português do Brasil.
Com base no material fornecido (uma transcrição ou notas de partes dela), escreva um relatório em Markdown com exatamente estas seções:

## Resumo
(um parágrafo de 3 a 6 frases)

## Assuntos discutidos
(lista curta)

## Decisões
(lista; escreva "Nenhuma decisão registrada" se não houver)

## Tarefas
(tabela com as colunas: Tarefa | Responsável | Prazo; use "—" quando não informado)

## Pendências e próximos passos
(lista)

Seja fiel ao conteúdo, não invente nomes, datas ou decisões. A transcrição pode ter erros: corrija palavras óbvias, mas na dúvida omita."""


def _chat(modelo, sistema, texto):
    try:
        r = requests.post(
            OLLAMA_URL,
            json={
                "model": modelo,
                "stream": False,
                "messages": [
                    {"role": "system", "content": sistema},
                    {"role": "user", "content": texto},
                ],
                "options": {"num_ctx": 8192, "temperature": 0.2},
            },
            timeout=900,
        )
    except requests.ConnectionError:
        raise RuntimeError(
            "Não consegui falar com o Ollama em localhost:11434. "
            "Ele está instalado e aberto? (https://ollama.com)"
        )
    if r.status_code == 404:
        raise RuntimeError(f"Modelo '{modelo}' não encontrado. Rode: ollama pull {modelo}")
    r.raise_for_status()
    return r.json()["message"]["content"].strip()


def _dividir(texto, tamanho=TAMANHO_PARTE):
    partes, atual = [], ""
    for linha in texto.splitlines(keepends=True):
        if len(atual) + len(linha) > tamanho and atual:
            partes.append(atual)
            atual = ""
        atual += linha
    if atual.strip():
        partes.append(atual)
    return partes


def _pasta_destino(arquivo, pasta):
    if pasta:
        destino = Path(pasta)
    elif PASTA_DIETPI.parent.exists():
        destino = PASTA_DIETPI
    else:
        destino = arquivo.parent
    destino.mkdir(parents=True, exist_ok=True)
    return destino


def gerar_relatorio(arquivo_transcricao, modelo="gemma3:4b", pasta=None):
    arquivo = Path(arquivo_transcricao)
    texto = arquivo.read_text(encoding="utf-8")
    if not texto.strip():
        raise RuntimeError("A transcrição está vazia: nenhuma legenda foi capturada.")

    partes = _dividir(texto)
    if len(partes) == 1:
        material = "Transcrição:\n\n" + texto
    else:
        notas = []
        for i, parte in enumerate(partes, 1):
            print(f"Resumindo parte {i} de {len(partes)}...")
            notas.append(f"### Parte {i}\n" + _chat(modelo, PROMPT_PARTE, parte))
        material = "Notas das partes da reunião:\n\n" + "\n\n".join(notas)

    print("Escrevendo o relatório final...")
    corpo = _chat(modelo, PROMPT_FINAL, material)

    cabecalho = (
        f"# Relatório da reunião\n\n"
        f"*Gerado em {datetime.now():%d/%m/%Y %H:%M} a partir de `{arquivo.name}` "
        f"com o modelo `{modelo}`. Resumo automático: confira os pontos importantes na transcrição.*\n\n"
    )
    destino = _pasta_destino(arquivo, pasta)
    saida = destino / (arquivo.stem.replace("_transcricao", "") + "_relatorio.md")
    saida.write_text(cabecalho + corpo + "\n", encoding="utf-8")
    print(f"Relatório salvo em: {saida}")

    # Guarda uma cópia da transcrição junto do relatório
    copia = destino / arquivo.name
    if copia.resolve() != arquivo.resolve():
        shutil.copy2(arquivo, copia)
        print(f"Transcrição copiada para: {copia}")
    return saida


if __name__ == "__main__":
    import argparse
    import sys

    p = argparse.ArgumentParser(description="Gera o relatório de uma transcrição salva pelo bot.")
    p.add_argument("arquivo", help="Arquivo *_transcricao.txt")
    p.add_argument("--modelo", default="gemma3:4b", help="Modelo do Ollama (padrão: gemma3:4b)")
    p.add_argument("--pasta", help="Onde salvar o relatório (padrão no DietPi: /mnt/dietpi_userdata/reunioes)")
    a = p.parse_args()
    try:
        gerar_relatorio(a.arquivo, a.modelo, a.pasta)
    except RuntimeError as e:
        print("Erro:", e)
        sys.exit(1)
