"""
Uso no servidor (depois de rodar instalar.sh):
  ata https://meet.google.com/abc-defg-hij

Ou diretamente:
  python3 main.py https://meet.google.com/abc-defg-hij

O bot entra na reunião, grava a transcrição pelas legendas e, quando a reunião
termina, gera o relatório. Tudo fica em /mnt/dietpi_userdata/reunioes (no DietPi)
ou na pasta ./reunioes (em outros sistemas).
"""

import argparse
import sys
from pathlib import Path

from meet_bot import MeetBot, fazer_login, tela_virtual

PASTA_DIETPI = Path("/mnt/dietpi_userdata/reunioes")
PASTA_PADRAO = str(PASTA_DIETPI) if PASTA_DIETPI.parent.exists() else "reunioes"


def main():
    p = argparse.ArgumentParser(
        description="Entra no Google Meet, transcreve pelas legendas e gera um relatório."
    )
    p.add_argument("link", nargs="?", help="Link da reunião (https://meet.google.com/...)")
    p.add_argument("--nome", default="Bot de Notas (gravando)", help="Nome exibido na reunião")
    p.add_argument("--saida", default=PASTA_PADRAO, help=f"Pasta dos arquivos (padrão: {PASTA_PADRAO})")
    p.add_argument("--modelo", default="gemma3:4b", help="Modelo do Ollama para o resumo")
    p.add_argument("--sem-resumo", action="store_true", help="Só transcreve, não gera o relatório")
    p.add_argument("--max-minutos", type=int, default=180, help="Duração máxima da gravação")
    p.add_argument("--perfil", default="perfil_navegador", help="Pasta do perfil do navegador")
    p.add_argument("--login", action="store_true", help="Entrar numa conta Google (exige tela)")
    p.add_argument("--debug", action="store_true", help="Salva o HTML da área de legendas")
    a = p.parse_args()

    try:
        if a.login:
            fazer_login(a.perfil)
            return
        if not a.link or "meet.google.com" not in a.link:
            p.error("informe o link da reunião, por exemplo: ata https://meet.google.com/abc-defg-hij")

        transcricao = MeetBot(a.link, a.nome, a.perfil, a.saida, a.max_minutos, a.debug).executar()

        if a.sem_resumo:
            return
        if not transcricao.exists() or not transcricao.read_text(encoding="utf-8").strip():
            print("Nenhuma fala foi capturada, então não há o que resumir.")
            return

        from resumo import gerar_relatorio  # só carrega se for resumir
        try:
            gerar_relatorio(transcricao, a.modelo, a.saida)
        except RuntimeError as e:
            print("A transcrição foi salva, mas o resumo falhou:", e)
            print(f"Tente depois: python3 resumo.py \"{transcricao}\"")
    except RuntimeError as e:
        print("Erro:", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
