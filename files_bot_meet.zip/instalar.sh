#!/usr/bin/env bash
# Instala o Meet Notas num servidor Debian/DietPi sem interface gráfica
# e cria o comando "ata". Uso: bash instalar.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo ">>> Instalando pacotes do sistema..."
apt-get update
apt-get install -y python3 python3-venv xvfb

echo ">>> Criando ambiente Python..."
python3 -m venv venv
venv/bin/pip install --upgrade pip
venv/bin/pip install -r requirements.txt

echo ">>> Instalando o navegador e suas dependências..."
venv/bin/python -m playwright install --with-deps chromium

echo ">>> Criando o comando 'ata'..."
cat > /usr/local/bin/ata << SCRIPT
#!/usr/bin/env bash
cd "$DIR" && exec "$DIR/venv/bin/python" main.py "\$@"
SCRIPT
chmod +x /usr/local/bin/ata

mkdir -p /mnt/dietpi_userdata/reunioes 2>/dev/null || true

if command -v ollama >/dev/null; then
  echo ">>> Baixando o modelo de resumo (gemma3:4b)..."
  ollama pull gemma3:4b
else
  echo "AVISO: Ollama não encontrado. Instale em https://ollama.com para gerar os resumos."
fi

echo
echo "Pronto! Para gravar uma reunião:  ata https://meet.google.com/abc-defg-hij"
