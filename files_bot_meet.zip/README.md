# Meet Notas: atas automáticas do Google Meet, gratuitas

Você informa o link, e o bot entra na reunião, liga as legendas automáticas do Meet, registra quem falou o quê e, quando a reunião termina, gera um relatório (resumo, decisões, tarefas e pendências) com um modelo de IA local via Ollama.

Funciona em servidor sem interface gráfica (CLI): o bot cria sozinho uma tela virtual (Xvfb) para o navegador.

## Instalação no servidor (Debian / DietPi)

1. Instale o Ollama, se ainda não tiver:
   ```
   curl -fsSL https://ollama.com/install.sh | sh
   ```
2. Copie a pasta `meet-notas` para o servidor (por exemplo, `/root/meet-notas`) e rode, como root:
   ```
   cd /root/meet-notas
   bash instalar.sh
   ```
   O script instala o Xvfb, o Python e o navegador, baixa o modelo `gemma3:4b` e cria o comando `ata`.

## Uso

```
ata https://meet.google.com/abc-defg-hij
```

Só isso. **Alguém na reunião precisa aceitar o bot** ("Bot de Notas (gravando)"). Ele grava até a reunião acabar, até ser removido ou até você apertar **Ctrl+C**, e então gera o relatório.

Os arquivos ficam em `/mnt/dietpi_userdata/reunioes` (visível no File Browser do DietPi Dashboard):
- `reuniao_AAAA-MM-DD_HH-MM_transcricao.txt`: a conversa com horário e nome de quem falou (salva a cada 15 s)
- `reuniao_AAAA-MM-DD_HH-MM_relatorio.md`: o relatório
- `reuniao_..._transcricao.erro.png`: só aparece se algo der errado, mostrando a tela do bot naquele momento

### Para não depender da sessão do terminal

Se o terminal fechar, o bot para. Para reuniões longas, rode em segundo plano:
```
nohup ata https://meet.google.com/abc-defg-hij > /mnt/dietpi_userdata/reunioes/ata.log 2>&1 &
```
Acompanhe com `tail -f /mnt/dietpi_userdata/reunioes/ata.log`. Para encerrar antes do fim da reunião: `pkill -INT -f main.py`.

### Opções

```
ata LINK --nome "Ata Automática"     # nome exibido na reunião
ata LINK --sem-resumo                # só transcreve
ata LINK --modelo gemma3:1b          # modelo mais leve para o resumo
ata LINK --max-minutos 90            # tempo máximo de gravação
```

Para gerar ou refazer o relatório de uma transcrição já salva:
```
cd /root/meet-notas && venv/bin/python resumo.py /mnt/dietpi_userdata/reunioes/reuniao_..._transcricao.txt
```

## Dicas e limitações

- **Convidado sem conta Google:** o bot entra como convidado. Algumas reuniões (principalmente de empresas com Google Workspace) não aceitam convidados de fora. Nesse caso, o arquivo `.erro.png` mostra a mensagem do Meet.
- **Idioma das legendas:** as legendas seguem o idioma da reunião. Se a transcrição sair em inglês, fale com o organizador ou ajuste o idioma de legendas da conta.
- **Primeiro teste:** faça uma reunião de teste com você mesmo antes de usar numa reunião importante.
- A qualidade depende das legendas automáticas do Google: nomes próprios e termos técnicos podem sair errados.
- **A interface do Meet muda com frequência.** Se o bot parar de clicar nos botões ou de ler as legendas, ajuste `PADROES` e `JS_LEGENDAS` em `meet_bot.py`. Rodar com `--debug` salva o HTML da área de legendas.
- **Pouca memória?** No `resumo.py`, troque `"num_ctx": 8192` por `4096` e `TAMANHO_PARTE = 12000` por `6000`.
- **Consentimento:** pela LGPD, avise os participantes que a reunião está sendo registrada. O nome padrão do bot já indica isso.
